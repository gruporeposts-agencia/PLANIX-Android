PLANIX Android v1.0 — proyecto listo para compilar

Qué incluye
- PLANIX v1.3 dentro de una app Android local.
- Funciona sin hosting y sin Internet.
- IndexedDB habilitado dentro del almacenamiento privado de la app.
- Icono PLANIX.
- Exportar respaldo abre el selector de Android para guardar el JSON.
- Restaurar respaldo abre el selector de archivos de Android.
- Identificador fijo de app: com.planix.local

IMPORTANTE ANTES DE INSTALAR
1. En la PLANIX v1.3 que usas actualmente en el navegador, pulsa “Exportar respaldo”.
2. Guarda el JSON en el teléfono.
3. Instala la APK compilada de este proyecto.
4. Abre PLANIX > Restaurar respaldo y selecciona el JSON.

Cómo generar el APK con Android Studio
1. Instala Android Studio en un computador.
2. Descomprime esta carpeta y abre la carpeta PLANIX_Android_v1.0 como proyecto.
3. Espera a que Gradle sincronice.
4. Ve a Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. El APK de prueba aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Actualizaciones futuras
- Mantener applicationId: com.planix.local.
- Aumentar versionCode en app/build.gradle.
- Instalar la nueva APK encima de la anterior, sin desinstalarla, para conservar los datos locales.
- Para una distribución definitiva, conviene firmar siempre las versiones con la misma clave.
